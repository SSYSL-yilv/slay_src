// ERROR: Could not find file 'res://src/Core/DevConsole/ConsoleCommands/GetLogsConsoleCommand.cs' in assembly 'sts2.dll'.
// The associated class(es) may have not been compiled into the assembly.