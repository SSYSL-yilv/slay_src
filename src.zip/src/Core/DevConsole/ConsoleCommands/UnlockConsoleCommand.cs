// ERROR: Could not find file 'res://src/Core/DevConsole/ConsoleCommands/UnlockConsoleCommand.cs' in assembly 'sts2.dll'.
// The associated class(es) may have not been compiled into the assembly.